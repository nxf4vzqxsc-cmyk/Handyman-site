
const toggle = document.getElementById('langToggle');
const nodes = document.querySelectorAll('[data-en]'); let current='en';
function applyLang(lang){
  nodes.forEach(n=>{ const d=n.dataset; if(lang==='ru'&&d.ru) n.textContent=d.ru; else if(lang==='zh'&&d.zh) n.textContent=d.zh; else n.textContent=d.en; });
  document.documentElement.lang = lang==='ru'?'ru':(lang==='zh'?'zh-Hans':'en');
  toggle.textContent = lang==='en'?'RU':(lang==='ru'?'中文':'EN');
  localStorage.setItem('lang', lang); current=lang;
}
toggle?.addEventListener('click',()=>applyLang(current==='en'?'ru':(current==='ru'?'zh':'en')));
applyLang(localStorage.getItem('lang')||'en');
