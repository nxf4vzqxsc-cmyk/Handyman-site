# Handyman Site (GitHub Pages)

This folder contains a ready-to-deploy static site for **Dmytro Handyman**.

## 🚀 Quick Deploy (GitHub Pages)
1. Create a repo on GitHub, e.g. `handyman-site`.
2. Upload all files from this folder to the repo root.
3. Go to **Settings → Pages**:
   - **Source**: `Deploy from a branch`
   - **Branch**: `main` / `/ (root)` → **Save**
4. Your site will be at: `https://&lt;your-github-username&gt;.github.io/&lt;repo-name&gt;/`

## ✉️ Contact form (Formspree)
- Replace the placeholder in `index.html` for `action="https://formspree.io/f/your-id"` with your Formspree endpoint.
- Or change the button to `mailto:booking@kuriletsrepair.com` only.

## 🧩 Customize
- Edit text in `index.html`, styles in `assets/styles.css`.
- Replace images in `assets/img/`.
- Update `phone`, `WhatsApp`, and `email`.
- Update `robots.txt` and `sitemap.xml` with your real GitHub username/repo.
