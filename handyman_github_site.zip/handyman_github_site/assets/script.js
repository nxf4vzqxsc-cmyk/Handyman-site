
// Simple RU/EN toggle
const toggle = document.getElementById('langToggle');
const nodes = document.querySelectorAll('[data-en]');
let current = 'en';

function applyLang(lang) {
  nodes.forEach(n => { n.textContent = n.dataset[lang]; });
  document.documentElement.lang = lang === 'ru' ? 'ru' : 'en';
  current = lang;
  toggle.textContent = lang === 'ru' ? 'EN' : 'RU';
  document.title = lang === 'ru' ? "Дмитрий — Мастер на все руки (NJ/NYC)" : "Dmytro Handyman — Jersey City & NYC";
}

toggle?.addEventListener('click', () => {
  applyLang(current === 'en' ? 'ru' : 'en');
});

// Persist language across visits
const saved = localStorage.getItem('lang');
if (saved) applyLang(saved);
toggle?.addEventListener('click', () => localStorage.setItem('lang', current));
